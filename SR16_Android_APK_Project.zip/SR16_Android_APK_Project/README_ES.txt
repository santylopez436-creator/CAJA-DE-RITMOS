SR16 RITMOS — PROYECTO ANDROID PARA GENERAR APK

Este proyecto empaqueta el programador de ritmos HTML dentro de una app Android.
La app está configurada para abrir siempre en horizontal, pantalla completa y sin necesitar internet.

IMPORTANTE: este paquete es el PROYECTO FUENTE de Android Studio, no un APK ya compilado.
En este entorno no está instalado el SDK de Android/Gradle, así que no puedo compilar y verificar un APK aquí.

CÓMO GENERAR EL APK EN ANDROID STUDIO (Windows/Linux):
1. Instala Android Studio desde la web oficial de Android Developers.
2. Descomprime SR16_Android_APK_Project.zip.
3. En Android Studio, elige Open y selecciona la carpeta SR16_Android_APK_Project.
4. Espera a que Gradle sincronice y descargue los componentes requeridos (se necesita internet para esta primera preparación).
5. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Al terminar, pulsa Locate en la notificación. El APK suele quedar en:
   app/build/outputs/apk/debug/app-debug.apk
7. Copia el APK al teléfono, ábrelo y autoriza instalar aplicaciones de esa fuente si Android lo solicita.

CARACTERÍSTICAS:
- Orientación horizontal fija.
- Pantalla completa.
- Interfaz HTML local dentro de la app.
- No solicita permiso de internet.
- El audio usa las capacidades Web Audio del WebView.

Si Android Studio solicita actualizar Gradle o instalar Android SDK Platform 35, acepta las sugerencias.
